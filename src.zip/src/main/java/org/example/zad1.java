package org.example;
public class zad1 {
    public static void main(String[] args) {
        String name = "Anton Smolik T-197";
        System.out.printf("Hello" + name);
    }
}